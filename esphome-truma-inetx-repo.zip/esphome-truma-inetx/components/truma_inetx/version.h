#pragma once
// Firmware version of the truma_inetx component. Bump on every change.
#define TRUMA_INETX_VERSION "0.6.0"
